static char *buildinfo = "Configured on 04/25/18 for x86_64-unknown-linux-gnu";
