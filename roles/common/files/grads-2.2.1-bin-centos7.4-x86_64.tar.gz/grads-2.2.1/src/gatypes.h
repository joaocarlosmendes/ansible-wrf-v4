 /************\
 * Data Types * 
 \************/
typedef double        gadouble;
typedef float         gafloat;
typedef int           gaint;
typedef unsigned long gaPixel;
typedef unsigned int  gauint;
typedef long int      galint;

