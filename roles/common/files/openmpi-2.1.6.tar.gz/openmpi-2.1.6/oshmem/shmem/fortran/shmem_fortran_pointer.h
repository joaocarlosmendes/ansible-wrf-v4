/*
 * Copyright (c) 2013      Mellanox Technologies, Inc.
 *                         All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#ifndef SHMEM_FORTRAN_POINTER_H
#define SHMEM_FORTRAN_POINTER_H

#define FORTRAN_POINTER_T uintptr_t
#define FPTR_2_VOID_PTR(a) ((void *)(a))

#endif
